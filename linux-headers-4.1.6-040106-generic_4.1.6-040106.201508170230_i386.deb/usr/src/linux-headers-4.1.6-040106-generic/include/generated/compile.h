/* This file is auto generated, version 201508170230 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#201508170230 SMP Mon Aug 17 06:44:49 UTC 2015"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 4.8.4 (Ubuntu 4.8.4-2ubuntu1~14.04) "
